# Samrat Case Review — Windows local-server installer

> **Release builder notice:** this folder contains the installer source and
> prepared application payload. It is not itself the client installer. Files
> ending in `.iss` and `.ps1` are expected to open as text/source files. On a
> Windows release machine, install Inno Setup 6 and double-click
> `01-BUILD-INSTALLER.cmd`. Give the client only the generated
> `output\Samrat-Case-Review-Setup-1.0.0-Installer2.exe` file.

This package installs Samrat Case Review and its private Supabase backend on a
dedicated Windows 10/11 x64 office computer. PostgreSQL data, user accounts,
and uploaded documents stay on that computer.

AI review is not offline: uploaded document content is sent through OpenRouter
to the configured Gemini model. An internet connection and an active
OpenRouter account are required for analysis.

## Client computer requirements

- Windows 10 or Windows 11, 64-bit, with virtualisation enabled
- Docker Desktop using the WSL 2 Linux engine
- 16 GB RAM recommended (8 GB minimum for light use)
- 20 GB free disk space initially, plus room for cases and backups
- Internet access during first installation and for Gemini analysis
- A private office network profile if other office computers will connect

Docker Desktop has separate commercial licensing terms. Confirm that the
client organisation qualifies for free use or purchase the required licence.

## Installation

1. Install and start Docker Desktop. Wait until it reports that the engine is running.
2. Run `Samrat-Case-Review-Setup-<version>-Installer2.exe` as an administrator.
3. Keep **Configure and start Samrat Case Review** checked at the end.
4. Paste the OpenRouter API key when requested.
5. Enter the email and password for the first Samrat administrator.
6. Sign in at `http://localhost:8888`.

From other computers on the same private office network, use
`http://WINDOWS-PC-NAME:8888`. Windows Firewall access is limited to the local
subnet and private network profile.

Installer 2 supports Docker Desktop's all-users and per-user installations,
registered custom folders, and discovery through its running app or CLI. Before
copying application files it checks the actual Linux engine and Docker Compose.
Run `02-CHECK-DOCKER.cmd` in the build kit to see the same read-only checks.
Docker installed but stopped, Windows container mode, and missing Compose are
reported separately. If UAC uses a different administrator account, that account
also needs access to Docker; test under the same account as setup.

An older EXE that says Docker is missing while Docker shows **Engine running**
needs rebuilding with this revision. Do not reset WSL or delete Docker data.
See `DOCKER-DETECTION-FIX.txt` for the small-patch instructions.

## Operations

The Start menu folder contains actions to start, stop, inspect, and back up
Samrat. Use **Add Samrat User** whenever another employee needs a login.
Backups are written to `Documents\Samrat Backups` by default. Each backup
contains a consistent PostgreSQL dump and all uploaded documents.

To restore, run PowerShell as administrator:

```powershell
& "C:\ProgramData\Samrat Case Review\scripts\Restore-Samrat.ps1" -BackupFolder "C:\path\to\samrat-YYYYMMDD-HHMMSS"
```

Uninstalling removes the containers and shortcuts but preserves database and
document files. Full data deletion is available only through
`Uninstall-Samrat.ps1 -RemoveData` and requires typing a destructive-action
confirmation.

## Release build

On a Windows release machine with Docker Desktop and Inno Setup 6:

For the prepared release kit, extract the full ZIP and double-click
`01-BUILD-INSTALLER.cmd`. It verifies the bundled application image, compiles
the setup program, and opens the output folder automatically.

The equivalent PowerShell command is:

```powershell
cd installer\windows
.\Build-Installer.ps1 -Version 1.0.0 -SkipImages
```

To rebuild the Linux application images as well as the setup program:

```powershell
cd installer\windows
.\Build-Installer.ps1 -Version 1.0.0
```

The build creates Linux/AMD64 web and worker images, saves them into the
installer payload, records a SHA-256 checksum that is verified before install
or update, and compiles the setup EXE into `output`.

The prepared release kit already contains the verified image payload, so its
normal one-click build does not rebuild Docker images.

For client distribution, sign the generated EXE with the organisation's
Windows code-signing certificate. Windows SmartScreen can warn users about an
unsigned installer even when its contents are valid.

The Supabase runtime is pinned to `self-hosted/v0.8.0`; see
`runtime\supabase\OFFICIAL_SOURCE.md` for its exact source commit.
